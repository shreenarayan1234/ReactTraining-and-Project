import React from 'react'
import { useState } from 'react'
import InputField from './InputField';
import Textarea from './Textarea';
import  Button  from './Button';

const Form = () => {
  const [data, setData] = useState({
    fname:'',
    email:'',
    subject:'',
    comment:'',
  });

  const handleChange = (field, value) =>{
    setData((preData)=>({
      ...preData,
      [field]:value,
    }));
  }

  
  const handleSubmit = (e) =>{
    e.preventDefault();
    console.log('Form Data', data);
  };
  return (
    <>
    <InputField
    label="Full Name"
    name="fname"
    value={data.fname}
    onChange={handleChange}
    />

     <InputField
    label="Email"
    name="email"
    value={data.email}
    onChange={handleChange}
    />

    <InputField
    label="Subject"
    name="subject"
    value={data.subject}
    onChange={handleChange}
    />

    <Textarea
      row={5}
      name="comment"
      value={data.comment}
      onChange={handleChange}
    />

    <Button
      handleSubmit={handleSubmit}
      text="Submit"
    />
    </>
  )
}

export default Form