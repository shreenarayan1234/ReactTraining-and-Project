import React from 'react'

const Header = () => {
  return (
    <>
      <h1>Registration Form</h1> 
    </>
  )
}

export default Header
