import React from 'react'

const Textarea = ({row,value,name,onChange}) => {
  const handleC = (e) =>{
    onChange(name,e.target.value);
  }
  return (
    <>
    <textarea rows={row} placeholder='your comment here' value={value} onChange={handleC} name={name}></textarea>
    </>
  )
}

export default Textarea