import React from 'react'

const InputField = ({label,name,value,onChange}) => {
  const handleC = (e) => {
    onChange(name,e.target.value);
  }
  return (
    <div>
      <label>
        {label}:
        <input type='text' name={name} value={value} onChange={handleC}/>
      </label>
    </div>
  )
}

export default InputField