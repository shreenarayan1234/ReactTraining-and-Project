import React from 'react'

const Button = ({handleSubmit, text}) => {
  return (
    <>
    <button onClick={handleSubmit}>{text}</button>
    </>
  )
}

export default Button