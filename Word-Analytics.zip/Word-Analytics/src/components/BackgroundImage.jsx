import React from 'react'

const BackgroundImage = () => {
  return (
    <div className='bg'/>
  )
}

export default BackgroundImage
